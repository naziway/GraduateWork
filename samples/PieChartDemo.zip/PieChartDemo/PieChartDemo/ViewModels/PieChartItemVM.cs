﻿namespace PieChartDemo.ViewModels
{
    public class PieChartItemVM
    {
        public string Name { get; set; }
        public double Value { get; set; }
    }
}
